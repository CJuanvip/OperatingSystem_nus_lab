/*************************************
* Lab 1 Exercise 2
* Name:
* Student No:
* Lab Group:
*************************************/

//declare your func_list array here
//remember to add in the keyword - extern

extern int (*func_list[5])(int);

void update_functions();


