/*************************************
* Lab 4
* Name:
* Student No:
* Lab Group:
*************************************/

#include "mmf.h"

void *mmf_create_or_open(const char *name, size_t sz) {
    /* TODO */
}

void mmf_close(void *ptr, size_t sz) {
    /* TODO */
}
