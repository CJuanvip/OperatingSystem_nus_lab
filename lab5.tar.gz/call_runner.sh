#!/bin/sh

LD_LIBRARY_PATH=. ./runner "$@"
